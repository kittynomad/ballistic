/*****************************************************************************
// File Name : PauseMenuService.cs
// Author : Pierce Nunnelley
// Creation Date : February 15, 2026
//
// Brief Description : This service handles functionality tied to the game's
// pause menu.
*****************************************************************************/
using UnityEngine;

public class PauseMenuService : Service
{

}
