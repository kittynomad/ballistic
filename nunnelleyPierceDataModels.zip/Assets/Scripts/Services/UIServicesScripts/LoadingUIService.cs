/*****************************************************************************
// File Name : LoadingUIService.cs
// Author : Pierce Nunnelley
// Creation Date : February 15, 2026
//
// Brief Description : This service handles behavior related to the loading
// screen UI.
*****************************************************************************/
using UnityEngine;

public class LoadingUIService : Service
{

}
