/*****************************************************************************
// File Name : HudService.cs
// Author : Pierce Nunnelley
// Creation Date : February 15, 2026
//
// Brief Description : This service handles behavior related to the primary
// gameplay hud.
*****************************************************************************/
using UnityEngine;

public class HudService : Service
{

}
