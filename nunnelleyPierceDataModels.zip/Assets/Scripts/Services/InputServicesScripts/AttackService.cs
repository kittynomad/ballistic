/*****************************************************************************
// File Name : AttackService.cs
// Author : Pierce Nunnelley
// Creation Date : February 15, 2026
//
// Brief Description : This service handles the player's attacking input.
*****************************************************************************/
using UnityEngine;

public class AttackService : Service
{

}
