/*****************************************************************************
// File Name : AimService.cs
// Author : Pierce Nunnelley
// Creation Date : February 15, 2026
//
// Brief Description : This service handles player aiming behavior.
*****************************************************************************/
using UnityEngine;

public class AimService : Service
{

}
