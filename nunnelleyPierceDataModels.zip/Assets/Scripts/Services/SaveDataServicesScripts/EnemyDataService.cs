/*****************************************************************************
// File Name : EnemyDataService.cs
// Author : Pierce Nunnelley
// Creation Date : February 15, 2026
//
// Brief Description : This service distributes data about enemies.
*****************************************************************************/
using UnityEngine;

public class EnemyDataService : Service
{

}
