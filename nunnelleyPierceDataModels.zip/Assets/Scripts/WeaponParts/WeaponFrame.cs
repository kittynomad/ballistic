using UnityEngine;

[System.Serializable]
public class WeaponFrame : WeaponPart
{

}
