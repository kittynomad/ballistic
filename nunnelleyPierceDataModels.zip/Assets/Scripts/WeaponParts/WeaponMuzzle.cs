using UnityEngine;

[System.Serializable]
public class WeaponMuzzle : WeaponPart
{
    
}
