using UnityEngine;

[System.Serializable]
public class WeaponAddon : WeaponPart
{

}
