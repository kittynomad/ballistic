/*****************************************************************************
// File Name : InputManager.cs
// Author : Pierce Nunnelley
// Creation Date : February 13, 2026
//
// Brief Description : This script initializes services for input-related
// behavior.
*****************************************************************************/
using UnityEngine;

public class InputManager : Manager
{

}
