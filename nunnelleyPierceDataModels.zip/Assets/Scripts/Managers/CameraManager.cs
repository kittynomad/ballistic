/*****************************************************************************
// File Name : CameraManager.cs
// Author : Pierce Nunnelley
// Creation Date : February 13, 2026
//
// Brief Description : This script manages camera behavior and functions.
*****************************************************************************/
using UnityEngine;

public class CameraManager : Manager
{
    
}
