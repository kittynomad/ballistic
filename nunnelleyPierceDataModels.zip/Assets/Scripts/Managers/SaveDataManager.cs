/*****************************************************************************
// File Name : SaveDataManager.cs
// Author : Pierce Nunnelley
// Creation Date : February 13, 2026
//
// Brief Description : This script initializes services for saved data.
*****************************************************************************/
using UnityEngine;

public class SaveDataManager : Manager
{
    
}
