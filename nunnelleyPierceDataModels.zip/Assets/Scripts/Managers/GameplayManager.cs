/*****************************************************************************
// File Name : GameplayManager.cs
// Author : Pierce Nunnelley
// Creation Date : February 13, 2026
//
// Brief Description : This script initializes services for gameplay related
// functionality.
*****************************************************************************/
using UnityEngine;

public class GameplayManager : Manager
{
    
}
