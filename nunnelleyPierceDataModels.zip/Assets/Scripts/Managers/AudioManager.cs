/*****************************************************************************
// File Name : AudioManager.cs
// Author : Pierce Nunnelley
// Creation Date : February 13, 2026
//
// Brief Description : This script manages sound effects and music.
*****************************************************************************/
using UnityEngine;

public class AudioManager : Manager
{
    
}
